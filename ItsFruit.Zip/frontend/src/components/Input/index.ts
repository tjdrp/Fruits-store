// src/components/Input/index.ts
export { default } from './Input';