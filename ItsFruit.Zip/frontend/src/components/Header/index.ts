// src/components/Header/index.ts
export { default } from './Header';