// src/components/Button/index.ts
export { default } from './Button';