// src/components/Footer/index.ts
export { default } from './Footer';