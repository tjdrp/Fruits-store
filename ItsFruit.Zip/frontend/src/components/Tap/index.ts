// src/components/Tap/index.ts
export { default } from './Tap';