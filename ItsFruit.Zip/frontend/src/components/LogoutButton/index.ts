// src/components/LogoutButton/index.ts
export { default } from './LogoutButton';