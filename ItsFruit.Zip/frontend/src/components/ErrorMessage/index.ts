// src/components/ErrorMessage/index.ts
export { default } from './ErrorMessage';