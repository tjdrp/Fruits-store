// src/components/Spinner/index.ts
export { default } from './Spinner';