// src/components/Layout/index.ts
export { default } from './Layout';