// src/components/Card/index.ts
export { default } from './Card';